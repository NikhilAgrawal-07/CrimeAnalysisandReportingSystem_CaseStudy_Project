package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.exception.VictimNotFoundException;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;

public class VictimDAOImpl implements IVictimDAO {

	private static Connection connVictim;

	@Override
	public int addVictim(Victims victim) throws ClassNotFoundException, SQLException {
		connVictim = DBUtil.createConnection();
		String query = "INSERT INTO Victims(FirstName,LastName,DateOfBirth,Gender,ContactInformation) VALUES(?,?,?,?,?)";
		int result = 0;
		Date Dob = Date.valueOf(victim.getDateOfBirth());

		PreparedStatement prepareStVictim = connVictim.prepareStatement(query);
		prepareStVictim.setString(1, victim.getFirstName());
		prepareStVictim.setString(2, victim.getLastName());
		prepareStVictim.setDate(3, Dob);
		prepareStVictim.setString(4, victim.getGender());
		prepareStVictim.setString(5, victim.getPhoneNumber());

		result = prepareStVictim.executeUpdate();

		DBUtil.closeConnection();

		return result;

	}

	@Override
	public int updateVictim(Victims victim) throws ClassNotFoundException, SQLException, VictimNotFoundException {
		connVictim = DBUtil.createConnection();
		String query = "UPDATE Victims SET FirstName=?,LastName=?,DateOfBirth=?,Gender=?,ContactInformation=? WHERE VictimID=?";
		int result = 0;
		Date Dob = Date.valueOf(victim.getDateOfBirth());

		PreparedStatement prepareStVictim = connVictim.prepareStatement(query);
		prepareStVictim.setString(1, victim.getFirstName());
		prepareStVictim.setString(2, victim.getLastName());
		prepareStVictim.setDate(3, Dob);
		prepareStVictim.setString(4, victim.getGender());
		prepareStVictim.setString(5, victim.getPhoneNumber());
		prepareStVictim.setInt(6, victim.getVictimID());

		result = prepareStVictim.executeUpdate();
		DBUtil.closeConnection();
		return result;

	}

	@Override
	public int deleteVictim(int victimId) throws ClassNotFoundException, SQLException, VictimNotFoundException {
		connVictim = DBUtil.createConnection();
		Victims victim = null;
		String firstName = null;
		String lastName = null;
		LocalDate Dob = null;
		String gender = null;
		String phoneNumber = null;
		int result = 0;

		String queryCheck = "SELECT * FROM Victims WHERE VictimID = ?";
		String queryDelete = "DELETE FROM Victims WHERE VictimID = ?";

		PreparedStatement prepareStVictim = connVictim.prepareStatement(queryCheck);
		PreparedStatement prepareVictimDelete = connVictim.prepareStatement(queryDelete);

		prepareStVictim.setInt(1, victimId);
		prepareVictimDelete.setInt(1, victimId);

		ResultSet rsVictims = prepareStVictim.executeQuery();

		while (rsVictims.next()) {// Till there are further records.
			victimId = rsVictims.getInt("VictimID");
			firstName = rsVictims.getString("firstname");
			lastName = rsVictims.getString("lastname");
			Dob = rsVictims.getDate("DateOfBirth").toLocalDate();
			gender = rsVictims.getString("Gender");
			phoneNumber = rsVictims.getString("ContactInformation");

			victim = new Victims(firstName, lastName, Dob, gender, phoneNumber);
			victim.setVictimID(victimId);
		}

		if (victim == null) {
			throw new VictimNotFoundException("No Victims Found");
		} else {
			result = prepareVictimDelete.executeUpdate();
		}

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public Victims viewVictim(int victimId) throws ClassNotFoundException, SQLException, VictimNotFoundException {
		connVictim = DBUtil.createConnection();
		Victims victim = null;
		String firstName = null;
		String lastName = null;
		LocalDate Dob = null;
		String gender = null;
		String phoneNumber = null;

		String query = "SELECT * FROM Victims WHERE VictimID = ?";

		PreparedStatement prepareStVictims = connVictim.prepareStatement(query);

		prepareStVictims.setInt(1, victimId);

		ResultSet rsVictims = prepareStVictims.executeQuery();

		while (rsVictims.next()) {// Till there are further records.
			victimId = rsVictims.getInt("VictimID");
			firstName = rsVictims.getString("firstname");
			lastName = rsVictims.getString("lastname");
			Dob = rsVictims.getDate("DateOfBirth").toLocalDate();
			gender = rsVictims.getString("Gender");
			phoneNumber = rsVictims.getString("ContactInformation");

			victim = new Victims(firstName, lastName, Dob, gender, phoneNumber);
			victim.setVictimID(victimId);
		}

		DBUtil.closeConnection();

		if (victim == null) {
			throw new VictimNotFoundException("No Victims Found");
		}

		return victim;
	}

	@Override
	public List<Victims> viewVictims() throws ClassNotFoundException, SQLException, VictimNotFoundException {
		List<Victims> victims = new ArrayList<>();
		connVictim = DBUtil.createConnection();
		Victims victim = null;
		String firstName = null;
		String lastName = null;
		LocalDate Dob = null;
		String gender = null;
		String phoneNumber = null;
		int VictimID = 0;

		String query = "SELECT * FROM Victims";

		PreparedStatement prepareStVictims = connVictim.prepareStatement(query);

		ResultSet rsVictims = prepareStVictims.executeQuery();

		while (rsVictims.next()) {// Till there are further records.
			VictimID = rsVictims.getInt("VictimID");
			firstName = rsVictims.getString("firstname");
			lastName = rsVictims.getString("lastname");
			Dob = rsVictims.getDate("DateOfBirth").toLocalDate();
			gender = rsVictims.getString("Gender");
			phoneNumber = rsVictims.getString("ContactInformation");

			victim = new Victims(firstName, lastName, Dob, gender, phoneNumber);
			victim.setVictimID(VictimID);
			victims.add(victim);
		}

		DBUtil.closeConnection();

		if (victims.size() == 0) {
			throw new VictimNotFoundException("No Victims Found");
		}

		return victims;
	}

}
