package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.OfficerNotFoundException;
import com.CrimeAnalysisAndReportingSystem.service.ILawEnforcementAgenciesService;
import com.CrimeAnalysisAndReportingSystem.service.LawEnforcementAgenciesServiceImpl;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;


public class OfficerDAOImpl implements IOfficerDAO {
private static Connection connOfficer;
	
	@Override
	public int addOfficer(Officers officer) throws ClassNotFoundException, SQLException {
		connOfficer = DBUtil.createConnection();
		String query = "INSERT INTO Officers(FirstName, LastName, BadgeNumber, Rankp, ContactInformation, AgencyID) " + "VALUES(?,?,?,?,?,?)";

		
		PreparedStatement prepareStOfficer = connOfficer.prepareStatement(query);
		prepareStOfficer.setString(1, officer.getFirstName());
		prepareStOfficer.setString(2, officer.getLastName());
		prepareStOfficer.setString(3, officer.getBadgeNumber());
		prepareStOfficer.setString(4, officer.getRank());
		prepareStOfficer.setString(5, officer.getPhoneNumber());
		prepareStOfficer.setInt(6, officer.getAgency().getAgencyId());

		int result = prepareStOfficer.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int updateOfficer(Officers officer) throws ClassNotFoundException, SQLException, OfficerNotFoundException {
		connOfficer = DBUtil.createConnection();
		String query = "UPDATE Officers SET FirstName=?, LastName=?, BadgeNumber=?, Rankp=?, ContactInformation=?, AgencyID=? "
				+ "WHERE OfficerID=?";
		
		PreparedStatement prepareStOfficer = connOfficer.prepareStatement(query);
		prepareStOfficer.setString(1, officer.getFirstName());
		prepareStOfficer.setString(2, officer.getLastName());
		prepareStOfficer.setString(3, officer.getBadgeNumber());
		prepareStOfficer.setString(4, officer.getRank());
		prepareStOfficer.setString(5, officer.getPhoneNumber());
		prepareStOfficer.setInt(6, officer.getAgency().getAgencyId());
		prepareStOfficer.setInt(7, officer.getOfficerId());
		
		int result = prepareStOfficer.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int deleteOfficer(int officerID) throws ClassNotFoundException, SQLException, OfficerNotFoundException {
		Officers officer = null;

		connOfficer = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM Officers WHERE OfficerID = ?";
		String queryDelete = "DELETE FROM Officers WHERE OfficerID = ?";

		String firstName = null;
		String lastName = null;
		String badgeNumber = null;
		String rank = null;
		String contactInfo = null;

		int success = 0;

		PreparedStatement prepareStOfficer = connOfficer.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connOfficer.prepareStatement(queryDelete);

		prepareStOfficer.setInt(1, officerID);
		prepareStDelete.setInt(1, officerID);

		ResultSet rsOfficer = prepareStOfficer.executeQuery();

		while (rsOfficer.next()) {// Till there are further records.
			officerID = rsOfficer.getInt("OfficerID");
			firstName = rsOfficer.getString("FirstName");
			lastName = rsOfficer.getString("LastName");
			badgeNumber = rsOfficer.getString("BadgeNumber");
			rank = rsOfficer.getString("Rankp");
			contactInfo = rsOfficer.getString("ContactInformation");
			

			officer = new Officers(firstName, lastName, badgeNumber, rank, contactInfo);
		}

		if (officer == null) {
			throw new OfficerNotFoundException("No Officer Found");
		} else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;
	}

	@Override
	public Officers viewOfficer(int officerID) throws ClassNotFoundException, SQLException, OfficerNotFoundException {
		lawEnforcementAgencies lea = null;
		Officers officer = null;

		int agencyID = 0;
		String agencyName = null;
		String jurisdiction = null;
		String contactInfo = null;
		String firstName = null;
		String lastName = null;
		String badgeNumber = null;
		String rank = null;
		String oContactInfo = null;
		
		
		connOfficer = DBUtil.createConnection();

		String queryCheck = "SELECT l.AgencyID, l.AgencyName, l.Jurisdiction ,l.ContactInformation ," 
				+ " o.OfficerID,o.FirstName, o.LastName, o.BadgeNumber,o.Rankp,o.ContactInformation"
				+ " FROM lawenforcementagencies l JOIN Officers o "
				+ "ON l.AgencyID = o.AgencyId "
				+ "WHERE o.OfficerID = ?";
		
				
		PreparedStatement prepareStOfficer = connOfficer.prepareStatement(queryCheck);
		prepareStOfficer.setInt(1, officerID);
		
		ResultSet rsOfficer = prepareStOfficer.executeQuery();

		while (rsOfficer.next()) {// Till there are further records.
			agencyID = rsOfficer.getInt("l.AgencyID");
			officerID = rsOfficer.getInt("o.OfficerID");
			agencyName = rsOfficer.getString("l.AgencyName");
			jurisdiction = rsOfficer.getString("l.Jurisdiction");
			contactInfo = rsOfficer.getString("l.ContactInformation");
			firstName = rsOfficer.getString("o.FirstName");
			lastName = rsOfficer.getString("o.LastName");
			badgeNumber = rsOfficer.getString("o.BadgeNumber");
			rank = rsOfficer.getString("o.Rankp");
			oContactInfo = rsOfficer.getString("o.ContactInformation");
			
			lea = new lawEnforcementAgencies(agencyID, agencyName, jurisdiction, contactInfo);
			officer = new Officers(officerID, firstName, lastName, badgeNumber, rank, oContactInfo, lea);
			
			
			
		}
		DBUtil.closeConnection();

		if (officer == null) {
			throw new OfficerNotFoundException("No Officer Found");
		}

		return officer;
	}

	@Override
	public List<Officers> viewOfficers() throws ClassNotFoundException, SQLException, OfficerNotFoundException {
		ILawEnforcementAgenciesService leaService = new LawEnforcementAgenciesServiceImpl();

		List<Officers> officers = new ArrayList<>();
		Officers officer = null;
		
		lawEnforcementAgencies lea = null;

		connOfficer = DBUtil.createConnection();

		String query = "SELECT * FROM Officers";

		int agencyID = 0;
		int officerID = 0;
		String firstName = null;
		String lastName = null;
		String badgeNumber = null;
		String rank = null;
		String oContactInfo = null;
		
		PreparedStatement prepareStrsOfficer = connOfficer.prepareStatement(query);

		ResultSet rsOfficer = prepareStrsOfficer.executeQuery();

		while (rsOfficer.next()) {// Till there are further records.
			agencyID = rsOfficer.getInt("AgencyID");
			officerID = rsOfficer.getInt("OfficerID");
			firstName = rsOfficer.getString("FirstName");
			lastName = rsOfficer.getString("LastName");
			badgeNumber = rsOfficer.getString("BadgeNumber");
			rank = rsOfficer.getString("Rankp");
			oContactInfo = rsOfficer.getString("ContactInformation");
			lea = leaService.viewLawEnforcementAgency(agencyID);
			
			officer = new Officers(officerID, firstName, lastName, badgeNumber, rank, oContactInfo, lea) ;
			officers.add(officer);
		}
		DBUtil.closeConnection();

		if (officers.size() == 0) {
			throw new OfficerNotFoundException("No officer Found");
		}

		return officers;
	}

}
