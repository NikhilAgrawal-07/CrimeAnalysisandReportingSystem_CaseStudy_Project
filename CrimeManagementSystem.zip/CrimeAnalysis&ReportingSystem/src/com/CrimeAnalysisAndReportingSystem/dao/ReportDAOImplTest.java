package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;



public class ReportDAOImplTest {
	private IReportDAO reportDAO;

	@Before
	public void setUp() throws Exception {
		reportDAO = new ReportDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		reportDAO = null;
	}

	@Test
	public final void testAddReport() {
		int result = 0;
		LocalDate date = LocalDate.of(2023, 11, 27);
		Incidents incident = new Incidents();
		int IncidentID = 10;
		incident.setIncidentID(IncidentID);
		Officers reportingOfficer = new Officers();
		int officerID = 10;
		reportingOfficer.setOfficerId(officerID);
		Reports report = new Reports(5, incident, reportingOfficer, date, "the crime is listed here", "Draft");
		try {
			result = reportDAO.addReport(report);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testUpdateReport() {
		int result = 0;
		LocalDate date = LocalDate.of(2023, 11, 21);
		Incidents incident = new Incidents();
		int IncidentID = 2;
		incident.setIncidentID(IncidentID);
		Officers reportingOfficer = new Officers();
		int officerID = 2;
		reportingOfficer.setOfficerId(officerID);
		Reports report = new Reports(2, incident, reportingOfficer, date, "the crime is listed here", "Draft");
		try {
			result = reportDAO.updateReport(report);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteReport() {
		int result = 0;
		int reportID = 4;
		try {
			result = reportDAO.deleteReport(reportID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(result == 1);
	}

	@Test
	public final void testViewReport() {
		Reports report = null;
		int reportID = 1;

		try {
			report = reportDAO.viewReport(reportID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(report != null);
	}

	@Test
	public final void testViewReports() {
		List<Reports> reportList = null;

		try {
			reportList = reportDAO.viewReports();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ReportNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(reportList != null);
	}

}
