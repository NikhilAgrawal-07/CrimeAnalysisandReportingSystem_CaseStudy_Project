package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Case;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.exception.CaseNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.IncidentNumberNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;


public interface ICrimeAnalysisDAO {
	public boolean createIncident(Incidents incident)throws ClassNotFoundException, SQLException;

	public boolean updateIncidentStatus(String status, int incidentId)throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public int updateIncident(Incidents incident)throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public int deleteIncident(int incidentID)throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public Incidents viewIncident(int incidentID)throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public List<Incidents> viewIncidents()throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public List<Incidents> getIncidentsInDateRange(LocalDate startDate, LocalDate endDate)throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public List<Incidents> searchIncidents(String incidentType)throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException;

	public Reports generateIncidentReport(Incidents incident)throws ClassNotFoundException, SQLException, ReportNotFoundException;

	public Boolean createCase(String caseDescription, Incidents incident)throws ClassNotFoundException, SQLException;

	public Case getCaseDetails(int caseId)throws ClassNotFoundException, SQLException, CaseNotFoundException;

	public boolean updateCaseDetails(Case case1)throws ClassNotFoundException, SQLException, CaseNotFoundException;

	public List<Case> getAllCases()throws ClassNotFoundException, SQLException, CaseNotFoundException;

}
