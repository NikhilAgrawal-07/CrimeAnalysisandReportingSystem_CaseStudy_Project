package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;

public interface IReportDAO {
	public int addReport(Reports report) throws ClassNotFoundException, SQLException;
	public int updateReport(Reports report) throws ClassNotFoundException, SQLException, ReportNotFoundException;
	public int deleteReport(int reportID) throws ClassNotFoundException, SQLException, ReportNotFoundException;
	public Reports viewReport(int reportID) throws ClassNotFoundException, SQLException, ReportNotFoundException;
	public List<Reports>viewReports() throws ClassNotFoundException, SQLException, ReportNotFoundException;

}
