package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.exception.OfficerNotFoundException;

public interface IOfficerDAO {
	public int addOfficer(Officers officer) throws ClassNotFoundException, SQLException;
	public int updateOfficer(Officers officer) throws ClassNotFoundException, SQLException, OfficerNotFoundException;
	public int deleteOfficer(int officerID) throws ClassNotFoundException, SQLException, OfficerNotFoundException;
	public Officers viewOfficer(int officerID) throws ClassNotFoundException, SQLException, OfficerNotFoundException;
	public List<Officers>viewOfficers() throws ClassNotFoundException, SQLException, OfficerNotFoundException;

}
