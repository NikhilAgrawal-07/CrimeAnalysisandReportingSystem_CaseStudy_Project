package com.CrimeAnalysisAndReportingSystem.service;

import java.time.LocalDate;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Case;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;

public interface ICrimeAnalysisService {

	public boolean createIncident(Incidents incident);

	public boolean updateIncidentStatus(String status, int incidentId);

	public int updateIncident(Incidents incident);

	public int deleteIncident(int incidentID);

	public Incidents viewIncident(int incidentID);

	public List<Incidents> viewIncidents();

	public List<Incidents> getIncidentsInDateRange(LocalDate startDate, LocalDate endDate);

	public List<Incidents> searchIncidents(String incidentType);

	public Reports generateIncidentReport(Incidents incident);

	public Boolean createCase(String caseDescription, Incidents incident);

	public Case getCaseDetails(int caseId);

	public boolean updateCaseDetails(Case case1);

	public List<Case> getAllCases();

}
