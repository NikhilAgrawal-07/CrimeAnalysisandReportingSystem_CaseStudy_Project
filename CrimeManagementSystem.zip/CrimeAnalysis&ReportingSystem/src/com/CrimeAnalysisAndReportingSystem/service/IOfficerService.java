package com.CrimeAnalysisAndReportingSystem.service;

import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Officers;

public interface IOfficerService {

	public int addOfficer(Officers officer);

	public int updateOfficer(Officers officer);

	public int deleteOfficer(int officerID);

	public Officers viewOfficer(int officerID);

	public List<Officers> viewOfficers();

}
