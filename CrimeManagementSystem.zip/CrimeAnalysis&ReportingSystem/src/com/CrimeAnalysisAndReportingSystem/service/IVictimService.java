package com.CrimeAnalysisAndReportingSystem.service;

import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Victims;

public interface IVictimService {
	
	public int addVictim(Victims victim);
	public int updateVictim(Victims victim);
	public int deleteVictim(int victimId);
	public Victims viewVictim(int victimId);
	public List<Victims>viewVictims();
}
