package com.CrimeAnalysisAndReportingSystem.service;

import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Evidence;

public interface IEvidenceService {
	public int addEvidence(Evidence evidence);
	public int updateEvidence(Evidence evidence);
	public int deleteEvidence(int evidenceID);
	public Evidence viewEvidence(int evidenceID);
	public List<Evidence>viewEvidences();
}
