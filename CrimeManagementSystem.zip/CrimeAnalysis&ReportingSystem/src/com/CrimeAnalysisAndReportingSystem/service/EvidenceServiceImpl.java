package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.EvidenceDAOImpl;
import com.CrimeAnalysisAndReportingSystem.dao.IEvidenceDAO;
import com.CrimeAnalysisAndReportingSystem.entity.Evidence;
import com.CrimeAnalysisAndReportingSystem.exception.EvidenceNotFoundException;

public class EvidenceServiceImpl implements IEvidenceService {


	private IEvidenceDAO evidenceDAO;

	public EvidenceServiceImpl() {
		this.evidenceDAO = new EvidenceDAOImpl();
	}
	
	@Override
	public int addEvidence(Evidence evidence) {
		int result = 0;
		try {
			result = evidenceDAO.addEvidence(evidence);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		return result;
	}

	@Override
	public int updateEvidence(Evidence evidence) {
		int result = 0;
		try {
			result = evidenceDAO.updateEvidence(evidence);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(EvidenceNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	@Override
	public int deleteEvidence(int evidenceID) {
		int result = 0;
		try {
			result = evidenceDAO.deleteEvidence(evidenceID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(EvidenceNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return result;
	}

	@Override
	public Evidence viewEvidence(int evidenceID) {
		Evidence evidence = null;

		try {
			evidence = evidenceDAO.viewEvidence(evidenceID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (EvidenceNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return evidence;
	}

	@Override
	public List<Evidence> viewEvidences() {
		List<Evidence> evidenceList = null;

		try {
			evidenceList = evidenceDAO.viewEvidences();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (EvidenceNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return evidenceList;
	}


}
