package com.CrimeAnalysisAndReportingSystem.service;

import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Suspects;

public interface ISuspectService {
	public int addSuspect(Suspects suspect);
	public int updateSuspect(Suspects suspect);
	public int deleteSuspect(int suspectId);
	public Suspects viewSuspect(int suspectId);
	public List<Suspects>viewSuspects();
}
