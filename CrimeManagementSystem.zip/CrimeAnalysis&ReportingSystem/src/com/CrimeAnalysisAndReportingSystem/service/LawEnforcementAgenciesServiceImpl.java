package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.ILawEnforcementAgenciesDAO;
import com.CrimeAnalysisAndReportingSystem.dao.LawEnforcementAgenciesDAOImpl;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.AgencyNotFoundException;


public class LawEnforcementAgenciesServiceImpl implements ILawEnforcementAgenciesService {
	private ILawEnforcementAgenciesDAO leaDAO;

	public LawEnforcementAgenciesServiceImpl() {
		this.leaDAO = new LawEnforcementAgenciesDAOImpl();
	}
	
	@Override
	public int addLawEnforcementAgency(lawEnforcementAgencies lea) {
		int result = 0;
		try {
			result = leaDAO.addLawEnforcementAgency(lea);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateLawEnforcementAgency(lawEnforcementAgencies lea) {
		int result = 0;
		try {
			result = leaDAO.updateLawEnforcementAgency(lea);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	@Override
	public int deleteLawEnforcementAgency(int agencyID) {
		int result = 0;
		try {
			result = leaDAO.deleteLawEnforcementAgency(agencyID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(AgencyNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return result;
	}

	@Override
	public lawEnforcementAgencies viewLawEnforcementAgency(int agencyID) {
		lawEnforcementAgencies lea = null;

		try {
			lea = leaDAO.viewLawEnforcementAgency(agencyID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return lea;
	}

	@Override
	public List<lawEnforcementAgencies> viewLawEnforcementAgencies() {
		List<lawEnforcementAgencies> leaList = null;

		try {
			leaList = leaDAO.viewLawEnforcementAgencies();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return leaList;
	}

}
