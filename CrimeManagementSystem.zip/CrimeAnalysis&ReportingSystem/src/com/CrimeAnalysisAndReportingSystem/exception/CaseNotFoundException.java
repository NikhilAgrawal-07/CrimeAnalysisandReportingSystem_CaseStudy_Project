package com.CrimeAnalysisAndReportingSystem.exception;

public class CaseNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CaseNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
