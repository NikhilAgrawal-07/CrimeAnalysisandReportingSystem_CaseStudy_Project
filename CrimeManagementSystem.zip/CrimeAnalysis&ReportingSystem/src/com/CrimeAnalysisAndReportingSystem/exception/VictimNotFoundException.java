package com.CrimeAnalysisAndReportingSystem.exception;

public class VictimNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VictimNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VictimNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
