package com.CrimeAnalysisAndReportingSystem.exception;

public class SuspectNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SuspectNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SuspectNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
