package com.CrimeAnalysisAndReportingSystem.exception;

public class IncidentNumberNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public IncidentNumberNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IncidentNumberNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
