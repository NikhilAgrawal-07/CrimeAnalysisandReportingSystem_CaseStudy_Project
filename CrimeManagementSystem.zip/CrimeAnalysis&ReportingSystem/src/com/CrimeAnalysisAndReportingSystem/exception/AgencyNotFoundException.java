package com.CrimeAnalysisAndReportingSystem.exception;

public class AgencyNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AgencyNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AgencyNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
