package com.CrimeAnalysisAndReportingSystem.entity;

import java.util.Objects;

public class Officers {
	 private int  officerId;
     private String firstName;
     private String lastName;
     private String badgeNumber;
     private String rank;
     private String phoneNumber;
     private lawEnforcementAgencies agency;
     
     
     public Officers(int officerId, String firstName, String lastName, String badgeNumber, String rank,
			String phoneNumber) {
		super();
		this.officerId = officerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.badgeNumber = badgeNumber;
		this.rank = rank;
		this.phoneNumber = phoneNumber;
	}
	public Officers(String firstName, String lastName, String badgeNumber, String rank, String phoneNumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.badgeNumber = badgeNumber;
		this.rank = rank;
		this.phoneNumber = phoneNumber;
	}
	public Officers(int officerId, String firstName, String lastName, String badgeNumber, String rank,
			String phoneNumber, lawEnforcementAgencies agency) {
		super();
		this.officerId = officerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.badgeNumber = badgeNumber;
		this.rank = rank;
		this.phoneNumber = phoneNumber;
		this.agency = agency;
	}
	public Officers(String firstName, String lastName, String badgeNumber, String rank, String phoneNumber,
			lawEnforcementAgencies agency) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.badgeNumber = badgeNumber;
		this.rank = rank;
		this.phoneNumber = phoneNumber;
		this.agency = agency;
	}
	public Officers() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getOfficerId() {
		return officerId;
	}
	public void setOfficerId(int officerId) {
		this.officerId = officerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getBadgeNumber() {
		return badgeNumber;
	}
	public void setBadgeNumber(String badgeNumber) {
		this.badgeNumber = badgeNumber;
	}
	public String getRank() {
		return rank;
	}
	public void setRank(String rank) {
		this.rank = rank;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public lawEnforcementAgencies getAgency() {
		return agency;
	}
	public void setAgency(lawEnforcementAgencies agency) {
		this.agency = agency;
	}
	@Override
	public int hashCode() {
		return Objects.hash(agency, badgeNumber, firstName, lastName, officerId, phoneNumber, rank);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Officers other = (Officers) obj;
		return Objects.equals(agency, other.agency) && Objects.equals(badgeNumber, other.badgeNumber)
				&& Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& officerId == other.officerId && Objects.equals(phoneNumber, other.phoneNumber)
				&& Objects.equals(rank, other.rank);
	}
	@Override
	public String toString() {
		return "Officers [officerId=" + officerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", badgeNumber=" + badgeNumber + ", rank=" + rank + ", phoneNumber=" + phoneNumber + ", agency="
				+ agency + "]";
	}
     
}