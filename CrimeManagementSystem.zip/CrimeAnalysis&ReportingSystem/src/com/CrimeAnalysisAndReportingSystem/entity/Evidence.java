package com.CrimeAnalysisAndReportingSystem.entity;

import java.util.Objects;

public class Evidence {
	private int evidenceId;
	private String Description;
	private String location;
	private Incidents incident;
	
	
	public Evidence(String description, String location) {
		super();
		Description = description;
		this.location = location;
	}
	public int getEvidenceId() {
		return evidenceId;
	}
	public void setEvidenceId(int evidenceId) {
		this.evidenceId = evidenceId;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Incidents getIncident() {
		return incident;
	}
	public void setIncident(Incidents incident) {
		this.incident = incident;
	}
	public Evidence(int evidenceId, String description, String location, Incidents incident) {
		super();
		this.evidenceId = evidenceId;
		Description = description;
		this.location = location;
		this.incident = incident;
	}
	public Evidence(String description, String location, Incidents incident) {
		super();
		Description = description;
		this.location = location;
		this.incident = incident;
	}
	public Evidence() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Evidence [evidenceId=" + evidenceId + ", Description=" + Description + ", location=" + location
				+ ", incident=" + incident + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(Description, evidenceId, incident, location);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Evidence other = (Evidence) obj;
		return Objects.equals(Description, other.Description) && evidenceId == other.evidenceId
				&& Objects.equals(incident, other.incident) && Objects.equals(location, other.location);
	}
	

}
