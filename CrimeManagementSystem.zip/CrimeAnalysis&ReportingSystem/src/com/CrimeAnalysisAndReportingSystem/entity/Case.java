package com.CrimeAnalysisAndReportingSystem.entity;

import java.util.Objects;

public class Case {
	private int CaseId;
	private String CaseDescription;
	private Incidents incident;
	
	public Case() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Case(String caseDescription, Incidents incident) {
		super();
		CaseDescription = caseDescription;
		this.incident = incident;
	}
	public Case(int caseId, String caseDescription, Incidents incident) {
		super();
		CaseId = caseId;
		CaseDescription = caseDescription;
		this.incident = incident;
	}
	public int getCaseId() {
		return CaseId;
	}
	public void setCaseId(int caseId) {
		CaseId = caseId;
	}
	public String getCaseDescription() {
		return CaseDescription;
	}
	public void setCaseDescription(String caseDescription) {
		CaseDescription = caseDescription;
	}
	public Incidents getIncident() {
		return incident;
	}
	public void setIncident(Incidents incident) {
		this.incident = incident;
	}
	@Override
	public String toString() {
		return "Case [CaseId=" + CaseId + ", CaseDescription=" + CaseDescription + ", incident=" + incident + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(CaseDescription, CaseId, incident);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Case other = (Case) obj;
		return Objects.equals(CaseDescription, other.CaseDescription) && CaseId == other.CaseId
				&& Objects.equals(incident, other.incident);
	}
	

}
