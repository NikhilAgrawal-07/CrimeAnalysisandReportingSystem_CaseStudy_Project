package com.CrimeAnalysisAndReportingSystem.main;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.CrimeAnalysisAndReportingSystem.entity.Case;
import com.CrimeAnalysisAndReportingSystem.entity.Evidence;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.service.CrimeAnalysisServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.EvidenceServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.ICrimeAnalysisService;
import com.CrimeAnalysisAndReportingSystem.service.IEvidenceService;
import com.CrimeAnalysisAndReportingSystem.service.ILawEnforcementAgenciesService;
import com.CrimeAnalysisAndReportingSystem.service.IOfficerService;
import com.CrimeAnalysisAndReportingSystem.service.IReportService;
import com.CrimeAnalysisAndReportingSystem.service.ISuspectService;
import com.CrimeAnalysisAndReportingSystem.service.IVictimService;
import com.CrimeAnalysisAndReportingSystem.service.LawEnforcementAgenciesServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.OfficerServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.ReportServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.SuspectServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.VictimServiceImpl;

public class MainModule {

	public static void main(String[] args) {
		int choice = -1;
		int innerChoice = -1;

		ICrimeAnalysisService incidentService = new CrimeAnalysisServiceImpl();
		IVictimService victimService = new VictimServiceImpl();
		ISuspectService suspectService = new SuspectServiceImpl();
		IEvidenceService evidenceService = new EvidenceServiceImpl();
		IOfficerService officerService = new OfficerServiceImpl();
		ILawEnforcementAgenciesService leaService = new LawEnforcementAgenciesServiceImpl();
		IReportService reportService = new ReportServiceImpl();

		Victims victim = null;
		Suspects suspect = null;
		Incidents incident = null;
		Evidence evidence = null;
		lawEnforcementAgencies agency = null;
		Officers reportingOfficer = null;// (Foreign Key, linking to Officers)
		Officers officer = null;
		Reports report = null;
		Case case1 = null;

		int VictimID = 0;// (Primary Key)
		String FirstName = null;
		String LastName = null;
		LocalDate DateOfBirth = null;
		int year = 0;
		int month = 0;
		int dayOfMonth = 0;
		String Gender = null;
		String ContactInfo = null;// (e.g., Address, Phone Number) we use phoneNumber

		int SuspectID = 0;

		int IncidentID = 0;
		String incidentType = null;
		LocalDate incidentDate = null;
		LocalDate startDate = null;
		LocalDate endDate = null;
		String location = null;
		String description = null;
		String status = null;

		int EvidenceID = 0;
		String locationFound = null;

		int OfficerID = 0;// (Primary Key)
		String badgeNumber = null;
		String rank = null;

		int AgencyID = 0;// (Primary Key)
		String agencyName = null;
		String jurisdiction = null;

		int ReportID = 0;// (Primary Key)
		LocalDate reportDate = null;
		String reportDetails = null;

		int CaseId;
		String CaseDescription;

		int success = 0;
		Boolean flag = false;

		Scanner scInput = new Scanner(System.in);

		while (choice != 0) {

			System.out.println("1.Incidents");
			System.out.println("2.Victims");
			System.out.println("3.Suspects");
			System.out.println("4.Law Enforcement Agencies");
			System.out.println("5.Evidence");
			System.out.println("6.Officers");
			System.out.println("7.Reports");
			System.out.println("0.Exit");
			System.out.println("Please Enter your choice:");

			choice = scInput.nextInt();

			switch (choice) {

			case 1:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Incident.");
					System.out.println("2. Update Incident.");
					System.out.println("3. Delete Incident.");
					System.out.println("4. View Incident by ID.");
					System.out.println("5. View all Incidents.");
					System.out.println("6. Update Incident Status.");
					System.out.println("7. View all Incidents in given Date range.");
					System.out.println("8. View all Incidents according to Incident Type.");
					System.out.println("9. Generate Incident Report.");
					System.out.println("10. Create Case.");
					System.out.println("11. View Case by ID.");
					System.out.println("12. Update Case Details.");
					System.out.println("13. View all Cases.");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.print("Enter Incident Type: ");
						incidentType = scInput.nextLine();

						System.out.println("Enter Incident Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						incidentDate = LocalDate.of(year, month, dayOfMonth);

						System.out.println("Enter the Location ");
						location = scInput.nextLine();
						
						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Status (eg. Open, Closed, Under Investigation): ");
						status = scInput.nextLine();

						System.out.print("Enter the Victim ID: ");
						VictimID = Integer.parseInt(scInput.nextLine());

						victim = new Victims();
						victim.setVictimID(VictimID);

						System.out.print("Enter the Suspect ID: ");
						SuspectID = Integer.parseInt(scInput.nextLine());

						suspect = new Suspects();
						suspect.setSuspectId(SuspectID);

						incident = new Incidents(incidentType, incidentDate, location, description, status, victim,
								suspect);

						flag = incidentService.createIncident(incident);

						if (flag == true) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.println("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Incident Type: ");
						incidentType = scInput.nextLine();

						System.out.println("Enter Incident Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						incidentDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("Enter the Location ");
						location = scInput.nextLine();

						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Status (eg. Open, Closed, Under Investigation): ");
						status = scInput.nextLine();

						System.out.print("Enter the Victim ID: ");
						VictimID = Integer.parseInt(scInput.nextLine());

						victim = new Victims();
						victim.setVictimID(VictimID);

						System.out.print("Enter the Suspect ID: ");
						SuspectID = Integer.parseInt(scInput.nextLine());

						suspect = new Suspects();
						suspect.setSuspectId(SuspectID);

						incident = new Incidents(IncidentID, incidentType, incidentDate, location, description, status,
								victim, suspect);

						success = incidentService.updateIncident(incident);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						success = incidentService.deleteIncident(IncidentID);

						if (success == 0) {
							System.out.println("No such incident");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						incident = incidentService.viewIncident(IncidentID);

						if (incident == null) {
							System.out.println("No such incident");
						} else {
							System.out.println("The given incident: ");
							System.out.println(incident);
						}
						break;
					case 5:
						List<Incidents> incidentList = incidentService.viewIncidents();

						if (incidentList == null) {
							System.out.println("No incidents in table.");
						} else {
							System.out.println("Following are the incidents:");

							for (Incidents incident2 : incidentList) {
								System.out.println(incident2);
							}
						}
						break;
					case 6:
						System.out.println("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Status (eg. Open, Closed, Under Investigation): ");
						status = scInput.nextLine();

						flag = incidentService.updateIncidentStatus(status, IncidentID);

						if (flag == true) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 7:
						System.out.println("Enter Start Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						startDate = LocalDate.of(year, month, dayOfMonth);

						System.out.println("Enter End Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						endDate = LocalDate.of(year, month, dayOfMonth);

						List<Incidents> incidentList1 = incidentService.getIncidentsInDateRange(startDate, endDate);

						if (incidentList1 == null) {
							System.out.println("No incidents in table.");
						} else {
							System.out.println("Following are the incidents:");

							for (Incidents incident2 : incidentList1) {
								System.out.println(incident2);
							}
						}
						break;
					case 8:
						System.out.print("Enter Incident Type: ");
						incidentType = scInput.nextLine();

						List<Incidents> incidentList2 = incidentService.searchIncidents(incidentType);

						if (incidentList2 == null) {
							System.out.println("No incidents in table.");
						} else {
							System.out.println("Following are the incidents:");

							for (Incidents incident2 : incidentList2) {
								System.out.println(incident2);
							}
						}
						break;
					case 9:
						System.out.println("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Incident Type: ");
						incidentType = scInput.nextLine();

						System.out.println("Enter Incident Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						incidentDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("Enter the Location ");
						location = scInput.nextLine();

						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Status (eg. Open, Closed, Under Investigation): ");
						status = scInput.nextLine();

						System.out.print("Enter the Victim ID: ");
						VictimID = Integer.parseInt(scInput.nextLine());

						victim = new Victims();
						victim.setVictimID(VictimID);

						System.out.print("Enter the Suspect ID: ");
						SuspectID = Integer.parseInt(scInput.nextLine());

						suspect = new Suspects();
						suspect.setSuspectId(SuspectID);

						incident = new Incidents(IncidentID, incidentType, incidentDate, location, description, status,
								victim, suspect);

						report = incidentService.generateIncidentReport(incident);
						if (report == null) {
							System.out.println("No such Report");
						} else {
							System.out.println("The given Report: ");
							System.out.println(report);
						}
						break;
					case 10:
						System.out.println("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Incident Type: ");
						incidentType = scInput.nextLine();

						System.out.println("Enter Incident Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						incidentDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("Enter the Location ");
						location = scInput.nextLine();

						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Status (eg. Open, Closed, Under Investigation): ");
						status = scInput.nextLine();

						System.out.print("Enter the Victim ID: ");
						VictimID = Integer.parseInt(scInput.nextLine());

						victim = new Victims();
						victim.setVictimID(VictimID);

						System.out.print("Enter the Suspect ID: ");
						SuspectID = Integer.parseInt(scInput.nextLine());

						suspect = new Suspects();
						suspect.setSuspectId(SuspectID);

						incident = new Incidents(IncidentID, incidentType, incidentDate, location, description, status,
								victim, suspect);

						System.out.print("Enter the Case Description:");
						CaseDescription = scInput.nextLine();

						flag = incidentService.createCase(CaseDescription, incident);

						if (flag == true) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 11:
						System.out.println("Enter Case ID: ");
						CaseId = scInput.nextInt();
						scInput.nextLine();

						case1 = incidentService.getCaseDetails(CaseId);

						if (case1 == null) {
							System.out.println("No such case");
						} else {
							System.out.println("The given case: ");
							System.out.println(case1);
						}
						break;
					case 12:
						System.out.println("Enter Incident ID: ");
						IncidentID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Incident Type: ");
						incidentType = scInput.nextLine();

						System.out.println("Enter Incident Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						incidentDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("Enter the Location ");
						location = scInput.nextLine();

						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Status (eg. Open, Closed, Under Investigation): ");
						status = scInput.nextLine();

						System.out.print("Enter the Victim ID: ");
						VictimID = Integer.parseInt(scInput.nextLine());

						victim = new Victims();
						victim.setVictimID(VictimID);

						System.out.print("Enter the Suspect ID: ");
						SuspectID = Integer.parseInt(scInput.nextLine());

						suspect = new Suspects();
						suspect.setSuspectId(SuspectID);

						incident = new Incidents(IncidentID, incidentType, incidentDate, location, description, status,
								victim, suspect);

						System.out.print("Enter the Case Id:");
						CaseId = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter the Case Description:");
						CaseDescription = scInput.nextLine();

						case1 = new Case(CaseId, CaseDescription, incident);

						flag = incidentService.updateCaseDetails(case1);

						if (flag == true) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 13:
						List<Case> cases = incidentService.getAllCases();

						if (cases == null) {
							System.out.println("No Cases in table.");
						} else {
							System.out.println("Following are the Cases:");

							for (Case case2 : cases) {
								System.out.println(case2);
							}
						}
						break;

					default:
						System.out.println("Exit.......");
						break;
					}
				}
			case 2:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Victim");
					System.out.println("2. Update Victim");
					System.out.println("3. Delete Victim");
					System.out.println("4. View Victim by ID");
					System.out.println("5. View all Victims");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.print("Enter first name: ");
						FirstName = scInput.nextLine();

						System.out.print("Enter last name: ");
						LastName = scInput.nextLine();

						System.out.println("Enter Date of Birth: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						DateOfBirth = LocalDate.of(year, month, dayOfMonth);

						System.out.print("Enter gender: ");
						Gender = scInput.nextLine();

						System.out.print("Enter phone number: ");
						ContactInfo = scInput.nextLine();

						victim = new Victims(FirstName, LastName, DateOfBirth, Gender, ContactInfo);

						success = victimService.addVictim(victim);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.print("Enter Victim ID: ");
						VictimID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter first name: ");
						FirstName = scInput.nextLine();

						System.out.print("Enter last name: ");
						LastName = scInput.nextLine();

						System.out.println("Enter Date of birth: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						DateOfBirth = LocalDate.of(year, month, dayOfMonth);

						System.out.print("Type of Gender: ");
						Gender = scInput.nextLine();

						System.out.print("Enter phone number: ");
						ContactInfo = scInput.nextLine();

						victim = new Victims(VictimID, FirstName, LastName, DateOfBirth, Gender, ContactInfo);

						success = victimService.updateVictim(victim);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Victim ID: ");
						VictimID = scInput.nextInt();
						scInput.nextLine();

						success = victimService.deleteVictim(VictimID);

						if (success == 0) {
							System.out.println("No such victim");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Victim ID: ");
						VictimID = scInput.nextInt();
						scInput.nextLine();

						victim = victimService.viewVictim(VictimID);

						if (victim == null) {
							System.out.println("No such victim");
						} else {
							System.out.println("The given victim: ");
							System.out.println(victim);
						}
						break;
					case 5:
						List<Victims> victimList = victimService.viewVictims();

						if (victimList == null) {
							System.out.println("No victims in table.");
						} else {
							System.out.println("Following are the victims:");

							for (Victims victim2 : victimList) {
								System.out.println(victim2);
							}
						}

						break;
					default:
						System.out.println("Exit.......");
						break;
					}
				}
			case 3:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Suspect");
					System.out.println("2. Update Suspect");
					System.out.println("3. Delete Suspect");
					System.out.println("4. View Suspect by ID");
					System.out.println("5. View all Suspects");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.print("Enter first name: ");
						FirstName = scInput.nextLine();

						System.out.print("Enter last name: ");
						LastName = scInput.nextLine();

						System.out.println("Enter Date of Birth: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						DateOfBirth = LocalDate.of(year, month, dayOfMonth);

						System.out.print("Enter gender: ");
						Gender = scInput.nextLine();

						System.out.print("Enter phone number: ");
						ContactInfo = scInput.nextLine();

						suspect = new Suspects(FirstName, LastName, DateOfBirth, Gender, ContactInfo);

						success = suspectService.addSuspect(suspect);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.print("Enter Suspect ID: ");
						SuspectID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter first name: ");
						FirstName = scInput.nextLine();

						System.out.print("Enter last name: ");
						LastName = scInput.nextLine();

						System.out.println("Enter Date of birth: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						DateOfBirth = LocalDate.of(year, month, dayOfMonth);

						System.out.print("Type of Gender: ");
						Gender = scInput.nextLine();

						System.out.print("Enter phone number: ");
						ContactInfo = scInput.nextLine();

						suspect = new Suspects(SuspectID, FirstName, LastName, DateOfBirth, Gender, ContactInfo);

						success = suspectService.updateSuspect(suspect);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Suspect ID: ");
						SuspectID = scInput.nextInt();
						scInput.nextLine();

						success = suspectService.deleteSuspect(SuspectID);

						if (success == 0) {
							System.out.println("No such suspect");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Suspect ID: ");
						SuspectID = scInput.nextInt();
						scInput.nextLine();

						suspect = suspectService.viewSuspect(SuspectID);

						if (suspect == null) {
							System.out.println("No such suspect");
						} else {
							System.out.println("The given suspect: ");
							System.out.println(suspect);
						}
						break;
					case 5:
						List<Suspects> suspectList = suspectService.viewSuspects();

						if (suspectList == null) {
							System.out.println("No suspects in table.");
						} else {
							System.out.println("Following are the suspects:");

							for (Suspects suspect2 : suspectList) {
								System.out.println(suspect2);
							}
						}

						break;
					default:
						System.out.println("Exit.......");
						break;
					}
				}
			case 4:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Law Enforcement Agencies");
					System.out.println("2. Update Law Enforcement Agencies");
					System.out.println("3. Delete Law Enforcement Agencies");
					System.out.println("4. View Law Enforcement Agencies by ID");
					System.out.println("5. View all Law Enforcement Agencies");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.print("Enter Agnecy name: ");
						agencyName = scInput.nextLine();

						System.out.print("Enter Jurisdiction: ");
						jurisdiction = scInput.nextLine();

						System.out.print("Enter phone number: ");
						ContactInfo = scInput.nextLine();

						agency = new lawEnforcementAgencies(agencyName, jurisdiction, ContactInfo);

						success = leaService.addLawEnforcementAgency(agency);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.println("Enter Agency ID: ");
						AgencyID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Agnecy name: ");
						agencyName = scInput.nextLine();

						System.out.print("Enter Jurisdiction: ");
						jurisdiction = scInput.nextLine();

						System.out.print("Enter phone number: ");
						ContactInfo = scInput.nextLine();

						agency = new lawEnforcementAgencies(AgencyID, agencyName, jurisdiction, ContactInfo);

						success = leaService.updateLawEnforcementAgency(agency);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Agency ID: ");
						AgencyID = scInput.nextInt();
						scInput.nextLine();

						success = leaService.deleteLawEnforcementAgency(AgencyID);

						if (success == 0) {
							System.out.println("No such Agency");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Agency ID: ");
						AgencyID = scInput.nextInt();
						scInput.nextLine();

						agency = leaService.viewLawEnforcementAgency(AgencyID);

						if (agency == null) {
							System.out.println("No such agency");
						} else {
							System.out.println("The given agency: ");
							System.out.println(agency);
						}
						break;
					case 5:
						List<lawEnforcementAgencies> agencyList = leaService.viewLawEnforcementAgencies();

						if (agencyList == null) {
							System.out.println("No agencies in table.");
						} else {
							System.out.println("Following are the agencies:");

							for (lawEnforcementAgencies agency2 : agencyList) {
								System.out.println(agency2);
							}
						}

						break;
					default:
						System.out.println("Exit.......");
						break;
					}
				}
			case 5:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Evidence");
					System.out.println("2. Update Evidence");
					System.out.println("3. Delete Evidence");
					System.out.println("4. View Evidence by ID");
					System.out.println("5. View all Evidence");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Location Found: ");
						locationFound = scInput.nextLine();

						System.out.print("Enter the Incident ID: ");
						IncidentID = Integer.parseInt(scInput.nextLine());

						incident = new Incidents();
						incident.setIncidentID(IncidentID);

						evidence = new Evidence(description, locationFound, incident);

						success = evidenceService.addEvidence(evidence);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.println("Enter Evidence ID: ");
						EvidenceID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter Description: ");
						description = scInput.nextLine();

						System.out.print("Enter Location Found: ");
						locationFound = scInput.nextLine();

						System.out.print("Enter the Incident ID: ");
						IncidentID = Integer.parseInt(scInput.nextLine());

						incident = new Incidents();
						incident.setIncidentID(IncidentID);

						evidence = new Evidence(EvidenceID, description, locationFound, incident);

						success = evidenceService.updateEvidence(evidence);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Evidence ID: ");
						EvidenceID = scInput.nextInt();
						scInput.nextLine();

						success = evidenceService.deleteEvidence(EvidenceID);

						if (success == 0) {
							System.out.println("No such Evidence");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Evidence ID: ");
						EvidenceID = scInput.nextInt();
						scInput.nextLine();

						evidence = evidenceService.viewEvidence(EvidenceID);

						if (evidence == null) {
							System.out.println("No such evidence");
						} else {
							System.out.println("The given evidence: ");
							System.out.println(evidence);
						}
						break;
					case 5:
						List<Evidence> evidenceList = evidenceService.viewEvidences();

						if (evidenceList == null) {
							System.out.println("No evidences in table.");
						} else {
							System.out.println("Following are the evidences:");

							for (Evidence evidence2 : evidenceList) {

								System.out.println(evidence2);
							}
						}

						break;
					default:
						System.out.println("Exit.......");
						break;
					}
				}
			case 6:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Officer");
					System.out.println("2. Update Officer");
					System.out.println("3. Delete Officer");
					System.out.println("4. View Officer by ID");
					System.out.println("5. View all Officers");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.print("Enter First Name: ");
						FirstName = scInput.nextLine();

						System.out.print("Enter Last Name: ");
						LastName = scInput.nextLine();

						System.out.print("Enter Badge Number: ");
						badgeNumber = scInput.nextLine();

						System.out.print("Enter Rank: ");
						rank = scInput.nextLine();

						System.out.print("Enter Phone number: ");
						ContactInfo = scInput.nextLine();

						System.out.print("Enter the Agency ID: ");
						AgencyID = Integer.parseInt(scInput.nextLine());

						agency = new lawEnforcementAgencies();
						agency.setAgencyId(AgencyID);

						officer = new Officers(FirstName, LastName, badgeNumber, rank, ContactInfo, agency);

						success = officerService.addOfficer(officer);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.println("Enter Officer ID: ");
						OfficerID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter First Name: ");
						FirstName = scInput.nextLine();

						System.out.print("Enter Last Name: ");
						LastName = scInput.nextLine();

						System.out.print("Enter Badge Number: ");
						badgeNumber = scInput.nextLine();

						System.out.print("Enter Rank: ");
						rank = scInput.nextLine();

						System.out.print("Enter Phone number: ");
						ContactInfo = scInput.nextLine();

						System.out.print("Enter the Agency ID: ");
						AgencyID = Integer.parseInt(scInput.nextLine());

						agency = new lawEnforcementAgencies();
						agency.setAgencyId(AgencyID);

						officer = new Officers(OfficerID, FirstName, LastName, badgeNumber, rank, ContactInfo, agency);

						success = officerService.updateOfficer(officer);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Officer ID: ");
						OfficerID = scInput.nextInt();
						scInput.nextLine();

						success = officerService.deleteOfficer(OfficerID);

						if (success == 0) {
							System.out.println("No such Officer");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Officer ID: ");
						OfficerID = scInput.nextInt();
						scInput.nextLine();

						officer = officerService.viewOfficer(OfficerID);

						if (officer == null) {
							System.out.println("No such officer");
						} else {
							System.out.println("The given officer: ");
							System.out.println(officer);
						}
						break;
					case 5:
						List<Officers> officerList = officerService.viewOfficers();

						if (officerList == null) {
							System.out.println("No officers in table.");
						} else {
							System.out.println("Following are the officers:");

							for (Officers officer2 : officerList) {

								System.out.println(officer2);
							}
						}

						break;
					default:
						System.out.println("Exit.......");
						break;
					}
				}
			case 7:
				while (innerChoice != 0) {
					System.out.println("Following are the options");
					System.out.println("1. Insert Report");
					System.out.println("2. Update Report");
					System.out.println("3. Delete Report");
					System.out.println("4. View Report by ID");
					System.out.println("5. View all Reports");
					System.out.println("0. Exit");
					System.out.println("Please enter your choice");

					innerChoice = scInput.nextInt();
					scInput.nextLine();

					switch (innerChoice) {
					case 1:
						System.out.println("Enter Report ID: ");
						ReportID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter the Incident ID: ");
						IncidentID = Integer.parseInt(scInput.nextLine());

						incident = new Incidents();
						incident.setIncidentID(IncidentID);

						System.out.print("Enter the Reporting Officer ID: ");
						OfficerID = Integer.parseInt(scInput.nextLine());

						reportingOfficer = new Officers();
						reportingOfficer.setOfficerId(OfficerID);

						System.out.print("Enter Report Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						reportDate = LocalDate.of(year, month, dayOfMonth);

						System.out.print("Enter Report Details: ");
						reportDetails = scInput.nextLine();

						System.out.print("Enter Status(eg. , Draft, Finalized): ");
						rank = scInput.nextLine();

						report = new Reports(ReportID, incident, reportingOfficer, reportDate, reportDetails, status);

						success = reportService.addReport(report);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.println("Enter Report ID: ");
						ReportID = scInput.nextInt();
						scInput.nextLine();

						System.out.print("Enter the Incident ID: ");
						IncidentID = Integer.parseInt(scInput.nextLine());

						incident = new Incidents();
						incident.setIncidentID(IncidentID);

						System.out.print("Enter the Reporting Officer ID: ");
						OfficerID = Integer.parseInt(scInput.nextLine());

						reportingOfficer = new Officers();
						reportingOfficer.setOfficerId(OfficerID);

						System.out.print("Enter Report Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());

						reportDate = LocalDate.of(year, month, dayOfMonth);

						System.out.print("Enter Report Details: ");
						reportDetails = scInput.nextLine();

						System.out.print("Enter Status(eg. , Draft, Finalized): ");
						status = scInput.nextLine();

						report = new Reports(ReportID, incident, reportingOfficer, reportDate, reportDetails, status);

						success = reportService.updateReport(report);

						if (success == 1) {
							System.out.println("Record updated successfully...");
						} else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Report ID: ");
						ReportID = scInput.nextInt();
						scInput.nextLine();

						success = reportService.deleteReport(ReportID);

						if (success == 0) {
							System.out.println("No such Report");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter Report ID: ");
						ReportID = scInput.nextInt();
						scInput.nextLine();

						report = reportService.viewReport(ReportID);

						if (report == null) {
							System.out.println("No such Report");
						} else {
							System.out.println("The given Report: ");
							System.out.println(report);
						}
						break;
					case 5:
						List<Reports> reportList = reportService.viewReports();

						if (reportList == null) {
							System.out.println("No Reports in table.");
						} else {
							System.out.println("Following are the Reports:");

							for (Reports report2 : reportList) {

								System.out.println(report2);
							}
						}

						break;
					default:
						System.out.println("Exit.......");
						break;
					}
				}
			}
		}
		scInput.close();

	}

}
